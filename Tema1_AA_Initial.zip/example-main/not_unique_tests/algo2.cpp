#include "algo.h"

int square(int x) {
    // other implementation
    int square = x * x;
    return square;
}
