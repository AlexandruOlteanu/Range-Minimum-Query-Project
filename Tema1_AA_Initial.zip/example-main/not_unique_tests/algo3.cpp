#include "algo.h"

int square(int x) {
    // something fancier
    if (x) {
        return x * x;
    }
    return 0;
}
