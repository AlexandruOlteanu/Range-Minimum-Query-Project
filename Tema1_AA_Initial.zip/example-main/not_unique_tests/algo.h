#ifndef ALGO_H
#define ALGO_H

int square(int x);

#endif
