#include "algo.h"

int square(int x) {
    return x * x;
}
